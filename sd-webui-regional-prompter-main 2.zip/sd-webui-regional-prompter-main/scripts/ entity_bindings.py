import re
from dataclasses import dataclass


ENTITY_DECL_RE = re.compile(
    r"@([A-Za-z][A-Za-z0-9_-]*)\s*=\s*([^,\n]+)",
    re.IGNORECASE,
)

ENTITY_REF_RE = re.compile(
    r"@([A-Za-z][A-Za-z0-9_-]*)(['’]s)?",
    re.IGNORECASE,
)

REGION_SPLIT_RE = re.compile(
    r"\b(ADDCOL|ADDROW)\b",
    re.IGNORECASE,
)

COUNT_RE = re.compile(
    r"\b(\d+)\s*(girls?|boys?|women|men)\b",
    re.IGNORECASE,
)


@dataclass
class Entity:
    alias: str
    canonical: str
    region_index: int
    kind: str


class EntityPromptError(ValueError):
    pass


def _character_kind(region_text: str) -> str:
    low = region_text.lower()

    if re.search(r"\b1girl\b", low):
        return "woman"

    if re.search(r"\b1boy\b", low):
        return "man"

    return "person"


def _other_label(entity: Entity) -> str:
    if entity.kind == "woman":
        return "the other woman"
    if entity.kind == "man":
        return "the other man"
    return "the other person"


def _split_common_and_regions(prompt: str):
    match = re.search(r"\bADDCOMM\b", prompt, re.IGNORECASE)

    if not match:
        return None

    common = prompt[:match.start()]
    body = prompt[match.end():]

    # Capturing split:
    #
    # [region0, ADDCOL, region1, ADDROW, region2 ...]
    pieces = REGION_SPLIT_RE.split(body)

    regions = []
    separators = []

    for i, piece in enumerate(pieces):
        if i % 2 == 0:
            regions.append(piece)
        else:
            separators.append(piece.upper())

    return common, regions, separators


def _discover_entities(regions):
    entities = {}

    for region_index, region in enumerate(regions):
        kind = _character_kind(region)

        for match in ENTITY_DECL_RE.finditer(region):
            alias = match.group(1).lower()
            canonical = match.group(2).strip()

            if alias in entities:
                previous = entities[alias]

                raise EntityPromptError(
                    f"@{alias} is declared more than once "
                    f"(regions {previous.region_index} and {region_index})."
                )

            entities[alias] = Entity(
                alias=alias,
                canonical=canonical,
                region_index=region_index,
                kind=kind,
            )

    return entities


def _all_references(text):
    return [
        match.group(1).lower()
        for match in ENTITY_REF_RE.finditer(text)
    ]


def _validate_references(text, entities):
    for alias in _all_references(text):
        if alias not in entities:
            raise EntityPromptError(
                f"Reference @{alias} has no declaration. "
                f"Declare it in a region with "
                f"'@{alias}=character name'."
            )


def _replace_reference(match, entities, owner_aliases=None, neutral=False):
    alias = match.group(1).lower()
    possessive = match.group(2)

    entity = entities[alias]

    if neutral:
        replacement = entity.canonical

    elif owner_aliases is None:
        replacement = entity.canonical

    elif alias in owner_aliases:
        replacement = entity.canonical

    else:
        replacement = _other_label(entity)

    if possessive:
        # "the other woman" -> "the other woman's"
        if replacement.endswith("s"):
            replacement += "'"
        else:
            replacement += "'s"

    return replacement


def _rewrite_text(text, entities, owner_aliases=None, neutral=False):
    return ENTITY_REF_RE.sub(
        lambda m: _replace_reference(
            m,
            entities,
            owner_aliases=owner_aliases,
            neutral=neutral,
        ),
        text,
    )


def _strip_entity_declarations(region, entities):
    def replacer(match):
        alias = match.group(1).lower()

        if alias not in entities:
            return match.group(0)

        # Declaration becomes the actual canonical character trigger.
        return entities[alias].canonical

    return ENTITY_DECL_RE.sub(replacer, region)


def _owners_for_region(region_index, entities):
    return {
        alias
        for alias, entity in entities.items()
        if entity.region_index == region_index
    }


def _split_common_clauses(common):
    """
    Prompt syntax is mostly comma-separated, so for v1 we deliberately
    keep this simple.

    Empty clauses are dropped.
    """
    result = []

    for line in common.splitlines():
        for clause in line.split(","):
            clause = clause.strip()

            if clause:
                result.append(clause)

    return result


def _validate_character_count(common, entities):
    """
    Only enforce an obvious simple count such as 2girls / 3girls.
    Don't try to guess mixed-gender counts yet.
    """
    matches = list(COUNT_RE.finditer(common))

    if len(matches) != 1:
        return

    expected = int(matches[0].group(1))

    if expected != len(entities):
        raise EntityPromptError(
            f"Prompt declares {expected} characters, "
            f"but {len(entities)} entity declarations were found: "
            + ", ".join("@" + x for x in entities)
        )


def compile_entity_prompt(prompt: str):
    """
    Compile @entity references while preserving the original
    ADDCOMM / ADDCOL / ADDROW spatial structure.

    Returns:
        compiled_prompt, report
    """

    parsed = _split_common_and_regions(prompt)

    # Old prompts continue working exactly as before.
    if parsed is None or "@" not in prompt:
        return prompt, None

    common, regions, separators = parsed

    entities = _discover_entities(regions)

    if not entities:
        # @ syntax exists but no declarations exist.
        raise EntityPromptError(
            "Entity references were used, but no entities were declared. "
            "Example: @yor=Yor Briar"
        )

    _validate_references(prompt, entities)
    _validate_character_count(common, entities)

    # ---------------------------------------------------------
    # Process common prompt
    #
    # Clauses with no @entity references stay global.
    #
    # Clauses beginning with an entity reference are moved
    # specifically to that entity's region.
    # ---------------------------------------------------------

    safe_common = []
    injected = {i: [] for i in range(len(regions))}

    for clause in _split_common_clauses(common):
        refs = _all_references(clause)

        if not refs:
            safe_common.append(clause)
            continue

        # Most useful form:
        #
        # @fiona hugging @yor
        # @yor being hugged by @fiona
        #
        # First entity owns the clause.
        first_alias = refs[0]
        owner = entities[first_alias]
        owner_aliases = {first_alias}

        rewritten = _rewrite_text(
            clause,
            entities,
            owner_aliases=owner_aliases,
        )

        injected[owner.region_index].append(rewritten)

    # ---------------------------------------------------------
    # Process individual regions
    # ---------------------------------------------------------

    compiled_regions = []

    for region_index, region in enumerate(regions):

        owner_aliases = _owners_for_region(
            region_index,
            entities,
        )

        # Turn @yor=Yor Briar into simply "Yor Briar".
        region = _strip_entity_declarations(
            region,
            entities,
        )

        if owner_aliases:
            # Character region:
            # its own @alias = canonical character name
            # foreign entity = "the other woman/man/person"
            region = _rewrite_text(
                region,
                entities,
                owner_aliases=owner_aliases,
            )
        else:
            # Non-character regions such as a dedicated feet region:
            # preserve ownership explicitly:
            #
            # @yor's feet -> Yor Briar's feet
            region = _rewrite_text(
                region,
                entities,
                neutral=True,
            )

        additions = injected.get(region_index, [])

        if additions:
            region = region.rstrip()
            region += ",\n" + ",\n".join(additions)

        compiled_regions.append(region)

    # ---------------------------------------------------------
    # Rebuild original RP geometry
    # ---------------------------------------------------------

    rebuilt_body = compiled_regions[0]

    for i, separator in enumerate(separators):
        rebuilt_body += f"\n{separator}\n"
        rebuilt_body += compiled_regions[i + 1]

    compiled = ", ".join(safe_common)

    if compiled:
        compiled += "\n"

    compiled += "ADDCOMM\n"
    compiled += rebuilt_body

    report = {
        "entities": {
            alias: {
                "canonical": entity.canonical,
                "region": entity.region_index,
                "kind": entity.kind,
            }
            for alias, entity in entities.items()
        },
        "global_clauses": safe_common,
        "injected": injected,
    }

    return compiled, report